import hashlib
import importlib.util
import json
import shutil
import subprocess
import sys
from datetime import datetime
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


OUT = Path(__file__).resolve().parent
DATA = OUT / "data"
FIG = OUT / "reproduced/figures"
QA = OUT / "qa"
TEAL = "#167D8D"
SLATE = "#637B96"
CORAL = "#CD6655"
INK = "#233746"
PALE = "#E9EFF2"
MODELS = ["Jev Noul", "Jev Choice", "Jev Choice+DEFER", "Qwen3.8-Flash", "GLM-5.3", "DeepSeek-Flash"]
SHORT = ["Noul", "Choice", "Choice+D", "Qwen", "GLM", "DeepSeek"]
INPUTS = []


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save_table(frame, name):
    frame.to_csv(DATA / name, index=False)


def save_figure(figure, name):
    figure.savefig(FIG / f"{name}.pdf", facecolor="white")
    figure.savefig(FIG / f"{name}.svg", facecolor="white")
    figure.savefig(FIG / f"{name}.png", dpi=600, facecolor="white")
    plt.close(figure)


def clean(axis):
    axis.spines[["top", "right"]].set_visible(False)
    axis.tick_params(length=2, width=0.5)
    axis.grid(False)
    axis.set_axisbelow(True)


def panel(axis, letter):
    axis.text(-0.16, 1.08, letter, transform=axis.transAxes, weight="bold", fontsize=8)


def main():
    FIG.mkdir(parents=True, exist_ok=True)
    plt.rcParams.update({"font.family":"sans-serif", "font.sans-serif":["DejaVu Sans"], "font.size":7, "axes.labelsize":7, "xtick.labelsize":6, "ytick.labelsize":6, "legend.fontsize":6, "axes.linewidth":0.6, "pdf.fonttype":42, "ps.fonttype":42, "svg.fonttype":"none"})
    cells = pd.read_csv(DATA / "all240_context_cells.csv")
    effects = pd.read_csv(DATA / "context_effects24.csv")
    factorial = pd.read_csv(DATA / "factorial_summary24.csv")
    endpoints = pd.read_csv(DATA / "v10_endpoint_strata.csv")
    differences = pd.read_csv(DATA / "v10_state_paired_differences.csv")
    temporal = pd.read_csv(DATA / "v11_all20_cells.csv")
    sensitivity = pd.read_csv(DATA / "v10_sensitivity4.csv").to_dict("records")
    for family, filename in [("task5", "figS1_mg_grid"), ("task9", "figS2_k_grid")]:
        fig, axes = plt.subplots(2, 6, figsize=(5, 3.3), sharex=True, sharey=True)
        xvalues = sorted(cells[cells.family == family].x.unique())
        for column, model in enumerate(MODELS):
            for row_index, mode in enumerate(["implicit", "explicit"]):
                axis = axes[row_index, column]
                for context, color in [("reduced", SLATE), ("full", TEAL)]:
                    group = cells[(cells.family == family) & (cells.model == model) & (cells["mode"] == mode) & (cells.context == context)].sort_values("x")
                    axis.plot(range(5), group.action_frequency, "o-", color=color, markersize=2, linewidth=0.8)
                axis.set_xticks(range(5), [f"{value:.2f}" for value in xvalues], rotation=90)
                axis.set_ylim(-0.06, 1.08)
                axis.set_yticks([0, 1])
                clean(axis)
                if row_index == 0:
                    axis.set_title(SHORT[column], fontsize=6)
        axes[0, 0].set_ylabel("Implicit\nAction frequency")
        axes[1, 0].set_ylabel("Explicit\nAction frequency")
        fig.text(0.53, 0.01, "Measured grid (teal: full; slate: reduced)", ha="center", fontsize=6)
        fig.subplots_adjust(left=0.10, right=0.99, top=0.90, bottom=0.20, wspace=0.25, hspace=0.24)
        save_figure(fig, filename)
    fig, axes = plt.subplots(1, 2, figsize=(5, 3.1), gridspec_kw={"width_ratios": [1.3, 1]})
    selected = endpoints[endpoints.family != "ALL"]
    labels = []
    for position, ((family, mode, context), group) in enumerate(selected.groupby(["family", "mode", "context"], sort=False)):
        labels.append(f"{'Mg' if family == 'task5' else 'K'} {mode[:3]} {context[:3]}")
        for offset, condition, color in [(-0.13, "control", SLATE), (0.13, "constrained", TEAL)]:
            item = group[group.condition == condition].iloc[0]
            axes[0].scatter(item.invalid / item.n * 100, position + offset, color=color, s=18)
    axes[0].set_yticks(range(8), labels)
    axes[0].invert_yaxis()
    axes[0].set_xlim(-2, 22)
    axes[0].set_xlabel("Invalid / all (%)")
    counts = [(differences.difference_pp < 0).sum(), (differences.difference_pp == 0).sum(), (differences.difference_pp > 0).sum()]
    axes[1].bar(["Lower", "Same", "Higher"], counts, color=[TEAL, SLATE, CORAL])
    for position, count in enumerate(counts):
        axes[1].text(position, count + 0.7, str(count), ha="center", fontsize=7)
    axes[1].set_ylim(0, 43)
    axes[1].set_ylabel("Fixed states")
    axes[1].set_xlabel("Reminder invalid rate")
    for index, axis in enumerate(axes):
        clean(axis)
        panel(axis, ["a", "b"][index])
    fig.subplots_adjust(left=0.21, right=0.98, bottom=0.23, top=0.88, wspace=0.65)
    save_figure(fig, "figS3_contract_strata")
    fig, axis = plt.subplots(figsize=(5, 2.3))
    grid = temporal.pivot_table(index=["mode", "context"], columns="offset_days", values="target_action").reindex(columns=[-30, -1, 0, 1, 30])
    axis.imshow(grid.to_numpy() / 3, cmap=matplotlib.colors.ListedColormap([PALE, TEAL]), vmin=0, vmax=1, aspect="auto")
    for row_index in range(4):
        for column in range(5):
            axis.text(column, row_index, f"{int(grid.iloc[row_index, column])}/3", ha="center", va="center", color="white" if grid.iloc[row_index, column] else INK, fontsize=7)
    axis.set_xticks(range(5), ["-30", "-1", "0", "+1", "+30"])
    axis.set_yticks(range(4), [f"{mode[:3]} / {context}" for mode, context in grid.index])
    axis.set_xlabel("Days from cutoff (equal spacing shows sampled categories)")
    axis.tick_params(length=0)
    for spine in axis.spines.values():
        spine.set_visible(False)
    fig.subplots_adjust(left=0.25, right=0.98, bottom=0.26, top=0.95)
    save_figure(fig, "figS4_temporal")
    fig, axis = plt.subplots(figsize=(5, 2.3))
    plotted = pd.DataFrame(sensitivity)
    for position, subset in enumerate(["all400", "complete398"]):
        for offset, condition, color in [(-0.12, "control", SLATE), (0.12, "constrained", TEAL)]:
            item = plotted[(plotted.subset == subset) & (plotted.condition == condition)].iloc[0]
            axis.scatter(position + offset, item.response_weighted_I * 100, color=color, s=30)
            axis.text(position + offset, item.response_weighted_I * 100 + 0.36, f"{int(item.invalid)}/{int(item.n)}", ha="center", fontsize=6)
    axis.set_xticks([0, 1], ["All responses", "Complete within-session blocks"])
    axis.set_ylabel("Invalid / all (%)")
    axis.set_ylim(0, 5.2)
    clean(axis)
    fig.subplots_adjust(left=0.14, right=0.97, bottom=0.23, top=0.94)
    save_figure(fig, "figS5_session")

    import runpy
    runpy.run_path(str(OUT / "plot_main_figures.py"), run_name="__main__")
    print("Rebuilt 10 figures into reproduced/figures")

if __name__ == "__main__":
    main()
