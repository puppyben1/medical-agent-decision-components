# Online Resource 2

State ranking, rule consistency and output contracts in medical agent decision components

Applied Intelligence

Xingkai Zhang, Mingchang Zhong, Xuejun Qiu, and Zhanpeng Huang

Correspondence: Xuejun Qiu (qiuxuejun@gdpu.edu.cn); Zhanpeng Huang (gdpuhzp@126.com).

## Contents and scope

`data/` contains 17 source tables and two minimized verdict exports. The native Jev table has 600 score/action records with request identifiers removed. The v10 and v11 exports contain 400 and 60 response verdicts, respectively. These overlapping tables are alternative views of the study responses, not additional samples. Technical replicates are not independent patients.

`python reproduce.py` uses Python 3.10 or later and the standard library. It verifies `integrity_manifest.json`, recomputes numerical results, and writes `reproduced/verification.json`. No API client, credentials, network, model call, or original local workspace is required.

`python plot_figures.py` rebuilds the included figure designs from these tables into `reproduced/figures/`; plotting requires the versions listed in `requirements-plotting.txt`. Existing PDF/SVG/PNG figures are in `figure_sources/`. Integrity hashes verify supplied files, not future byte-identical rendering across plotting environments.

`source_provenance.json` records SHA-256 digests of retained v10/v11 research records. It does not supply those original records. The archive reproduces numerical summaries from the exported analysis variables; it does not independently rerun raw-response parsing, payload hashing, or transport audits. Original requests/responses, benchmark-derived FHIR resource text, third-party papers, private configuration, and credentials are outside this archive. Source-specific reuse terms are not inferred from the upstream software license.

## Data dictionary

- `table1_design_inventory.csv`: batch-level physical requests, normal returns and analyzed responses; v7 observations retained in v8 are counted once in analyzed totals.
- `all48_context_strata.csv`, `all240_context_cells.csv`: 1,200-response comparison, grouped into 48 strata and 240 five-repeat state cells.
- `context_effects24.csv`: paired full-minus-reduced context contrasts; I and C divide by all responses, M by valid responses.
- `jev_v6_per_response.csv`, `native_auroc24.csv`: 600 native Jev records and AUROC over five state-mean scores in each configuration; B1 uses score >=0.5, B2/B3 use native choices.
- `all120_factorial_cells.csv`, `factorial_summary24.csv`, `factor_effects6.csv`: 600-response Mg factorial, summaries, and descriptive percentage-point contrasts.
- `v10_response_verdicts.csv`: parsed action, strict validity, correctness, condition, synthetic state label, technical repeat, session and paired block for each of 400 responses.
- `v10_endpoint_strata.csv`, `v10_state_paired_differences.csv`: overall/eight stratum endpoints and state-level reminder contrasts.
- `v10_sensitivity4.csv`, `session_comparisons.csv`: session and within-session complete-block sensitivity; block 124 spans sessions.
- `v11_response_verdicts.csv`, `v11_all20_cells.csv`: 60 temporal verdicts and 20 state cells; negative offsets are strictly before the cutoff; equality does not trigger recheck.
- `oracle_checks60.csv`: saved deterministic-rule checks for 40 numerical and 20 temporal states.
- `transition_brackets48.csv`, `state_context_transitions120.csv`: discrete transition summaries and context transitions across the sampled states.

`strict_valid` and `strict_correct` use 0/1 coding. The truncated observed label REPLACE_POTASSIUM remains invalid and is never mapped to the required REPLACE_POTASSIUM_AND_RECHECK label.

observed_action is the action accepted by the strict parser and is blank for an invalid header. header_action_label preserves the literal first-line label for failure analysis; it is not a repaired or accepted action.
