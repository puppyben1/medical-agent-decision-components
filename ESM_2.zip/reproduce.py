"""Recompute article summaries from supplied analysis variables, without API calls."""
import csv
import hashlib
import json
from collections import defaultdict
from pathlib import Path
from statistics import mean

ROOT = Path(__file__).resolve().parent
DATA = ROOT / 'data'
OUT = ROOT / 'reproduced'
CHECKS = []


def read(name):
    with (DATA / name).open(encoding='utf-8-sig', newline='') as f:
        return list(csv.DictReader(f))


def check(name, condition, observed=None):
    CHECKS.append({'check': name, 'passed': bool(condition), 'observed': observed})
    if not condition:
        raise AssertionError(name + ': ' + str(observed))


def groups(rows, fields):
    result = defaultdict(list)
    for row in rows:
        result[tuple(row[f] for f in fields)].append(row)
    return result


def count(rows, field):
    return sum(int(r[field]) for r in rows)


def main():
    manifest = ROOT / 'integrity_manifest.json'
    check('Integrity manifest supplied', manifest.exists())
    for item in json.loads(manifest.read_text(encoding='utf-8')):
        file = ROOT / item['file']
        check('SHA256 ' + item['file'], file.is_file() and hashlib.sha256(file.read_bytes()).hexdigest() == item['sha256'])
    ledger = read('table1_design_inventory.csv')
    totals = {k: count(ledger, k) for k in ['physical_attempts', 'successful_new_responses', 'analysis_responses']}
    check('Study ledger', list(totals.values()) == [4068, 4062, 4060], totals)
    strata = read('all48_context_strata.csv')
    cells = read('all240_context_cells.csv')
    primary = {k: count(strata, k) for k in ['calls', 'correct', 'output_contract_invalid', 'valid_label_rule_mismatch']}
    check('Primary comparison and mutually exclusive counts', list(primary.values()) == [1200, 1071, 7, 122], primary)
    by_cell = groups(cells, ['model', 'family', 'mode', 'context'])
    for r in strata:
        g = by_cell[(r['instrument'], r['family'], r['mode'], r['context'])]
        n, valid, correct = (count(g, k) for k in ['n', 'valid_calls', 'correct_calls'])
        check('State cells reproduce stratum ' + '/'.join([r['instrument'], r['family'], r['mode'], r['context']]), [n, correct, n-valid, valid-correct] == [int(r[k]) for k in ['calls', 'correct', 'output_contract_invalid', 'valid_label_rule_mismatch']])
    effects = read('context_effects24.csv')
    lookup = {(r['instrument'], r['family'], r['mode'], r['context']): r for r in strata}
    for e in effects:
        rates = {}
        for context in ['reduced', 'full']:
            r = lookup[(e['instrument'], e['family'], e['mode'], context)]
            n, invalid, correct, mismatch = [int(r[k]) for k in ['calls', 'output_contract_invalid', 'correct', 'valid_label_rule_mismatch']]
            valid = n-invalid
            rates[context] = [invalid/n, correct/n, mismatch/valid]
            check('Endpoint identity ' + str((e['instrument'], e['family'], e['mode'], context)), abs(correct/n-(1-invalid/n)*(1-mismatch/valid)) < 1e-12)
            for metric, rate in zip(['I', 'C', 'M'], rates[context]):
                check('Context rate ' + metric, abs(rate-float(e[f'{context}_{metric}'])) < 1e-12)
        for i, metric in enumerate(['I', 'C', 'M']):
            check('Context contrast ' + metric, abs(100*(rates['full'][i]-rates['reduced'][i])-float(e[f'delta_{metric}_pp'])) < 1e-9)
    native = read('jev_v6_per_response.csv')
    aurocs = {}
    correct_counts = {}
    for key, g in groups(native, ['family', 'mode', 'context', 'arm']).items():
        state_scores = []
        for _, sg in groups(g, ['x']).items():
            state_scores.append((mean(float(r['score']) for r in sg), sg[0]['expected'] == 'ACTION'))
        pos, neg = [[v for v, label in state_scores if label == truth] for truth in [True, False]]
        auc = mean(float(p > n) + 0.5*float(p == n) for p in pos for n in neg)
        aurocs[key] = auc
        if key[-1] == 'B1':
            check('B1 frozen score threshold', all((float(r['score']) >= 0.5) == (r['action'] == 'ACTION') for r in g))
        correct_counts[key] = sum(r['action'] == r['expected'] for r in g)
    for r in read('native_auroc24.csv'):
        check('Five-state AUROC ' + '/'.join(r[k] for k in ['family', 'mode', 'context', 'arm']), abs(aurocs[tuple(r[k] for k in ['family', 'mode', 'context', 'arm'])]-float(r['auroc'])) < 1e-12)
    for arm in ['B1', 'B2', 'B3']:
        check('Mg ranking and action ' + arm, aurocs[('task5', 'implicit', 'reduced', arm)] == 1 and correct_counts[('task5', 'implicit', 'reduced', arm)] == 5 and correct_counts[('task5', 'implicit', 'full', arm)] == 25)
    factorial = read('all120_factorial_cells.csv')
    factorial_groups = groups(factorial, ['mode', 'arm', 'context'])
    rates = {}
    for r in read('factorial_summary24.csv'):
        key = tuple(r[k] for k in ['mode', 'arm', 'context'])
        g = factorial_groups[key]
        n, correct = count(g, 'n'), count(g, 'correct_calls')
        check('Factorial summary ' + '/'.join(key), n == int(r['n']) and correct == int(r['correct_calls']))
        rates[key] = correct/n
    for r in read('factor_effects6.csv'):
        q = lambda c: rates[(r['mode'], r['arm'], c)]
        calculated = {'range_at_L0_pp': 100*(q('L0R1')-q('L0R0')), 'range_at_L1_pp': 100*(q('L1R1')-q('L1R0')), 'name_at_R0_pp': 100*(q('L1R0')-q('L0R0')), 'name_at_R1_pp': 100*(q('L1R1')-q('L0R1')), 'difference_in_differences_pp': 100*(q('L1R1')-q('L1R0')-q('L0R1')+q('L0R0'))}
        check('Factorial contrasts ' + r['mode'] + '/' + r['arm'], all(abs(v-float(r[k])) < 1e-9 for k,v in calculated.items()), calculated)
    v10 = read('v10_response_verdicts.csv')
    v11 = read('v11_response_verdicts.csv')
    check('Fresh comparison and temporal sample sizes', [len(v10), len(v11)] == [400, 60])
    for name, rows in [('v10', v10), ('v11', v11)]:
        check(name + ' correctness reconstructed from validity/action', all(int(r['strict_correct']) == int(int(r['strict_valid']) and r['observed_action'] == r['expected_action']) for r in rows))
    def endpoint(rows):
        n, valid, correct = len(rows), count(rows, 'strict_valid'), count(rows, 'strict_correct')
        return [n, n-valid, correct, valid, valid-correct]
    for r in read('v10_endpoint_strata.csv'):
        g = [x for x in v10 if x['condition'] == r['condition'] and (r['family'] == 'ALL' or all(x[k] == r[k] for k in ['family', 'mode', 'context']))]
        check('Reminder endpoints ' + '/'.join(r[k] for k in ['condition', 'family', 'mode', 'context']), endpoint(g) == [int(r[k]) for k in ['n', 'invalid', 'correct', 'valid', 'rule_mismatch']])
    bad = [r for r in v10 if r['strict_valid'] == '0']
    check('Invalid compound labels retained', len(bad) == 15 and all(r['family'] == 'task9' and r['context'] == 'full' and r['observed_action'] == '' and r['header_action_label'] == 'REPLACE_POTASSIUM' for r in bad))
    blocks = groups(v10, ['block_id'])
    cross = [k[0] for k,g in blocks.items() if len({r['session_id'] for r in g}) > 1]
    check('Cross-session paired block', cross == ['124'], cross)
    for r in read('v10_sensitivity4.csv'):
        g = [x for x in v10 if x['condition'] == r['condition'] and (r['subset'] == 'all400' or x['block_id'] not in cross)]
        n, invalid, *_ = endpoint(g)
        state_rate = mean(mean(1-int(x['strict_valid']) for x in sg) for sg in groups(g, ['state_id']).values())
        check('Session sensitivity ' + r['subset'] + '/' + r['condition'], n == int(r['n']) and invalid == int(r['invalid']) and abs(invalid/n-float(r['response_weighted_I'])) < 1e-12 and abs(state_rate-float(r['state_equal_weighted_I'])) < 1e-12)
    for r in read('v11_all20_cells.csv'):
        g = [x for x in v11 if x['state_id'] == r['state_id']]
        check('Temporal state ' + r['state_id'], endpoint(g)[:4] == [int(r[k]) for k in ['n', 'invalid', 'correct', 'valid']] and all((int(x['offset_days']) < 0) == (x['expected_action'] == 'RECHECK_HBA1C') for x in g))
    check('Temporal observed ceiling and equality', count(v11, 'strict_correct') == 60 and sum(int(r['strict_correct']) for r in v11 if int(r['offset_days']) == 0) == 12)
    check('Saved deterministic reference checks', all(r['matches'] == 'True' for r in read('oracle_checks60.csv')))
    OUT.mkdir(exist_ok=True)
    report = {'scope': 'Offline reproduction from supplied analysis variables; raw parsing and transport audits are separate.', 'new_model_calls': 0, 'checks_passed': len(CHECKS), 'checks_failed': sum(not r['passed'] for r in CHECKS), 'ledger': totals, 'primary_comparison': primary, 'checks': CHECKS}
    (OUT / 'verification.json').write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps({k:report[k] for k in ['checks_passed', 'checks_failed', 'new_model_calls']}, indent=2))


if __name__ == '__main__':
    main()
