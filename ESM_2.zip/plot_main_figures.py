"""Redraw the main figures from preserved aggregate tables without new observations."""
import hashlib
import json
from pathlib import Path

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch
from matplotlib.text import Text
import numpy as np
import pandas as pd

OUT = Path(__file__).resolve().parent
WORK = OUT / 'reproduced'
DATA = OUT / 'data'
FIG = WORK / 'figures'
TEAL, SLATE, INK = '#167D8D', '#637B96', '#233746'
MODELS = ['Jev Noul', 'Jev Choice', 'Jev Choice+DEFER', 'Qwen3.8-Flash', 'GLM-5.3', 'DeepSeek-Flash']
SHORT = ['Noul', 'Choice', 'Choice+DEFER', 'Qwen', 'GLM', 'DeepSeek']
ARMS = ['B1', 'B2', 'B3']


def clean(ax):
    ax.spines[['top', 'right']].set_visible(False)
    ax.tick_params(length=3, width=0.6)
    ax.set_axisbelow(True)


def save(fig, name):
    # sn-jnl scales 7.08-inch exports to about 5.15 inches. Preserve >=8 pt lettering.
    for text in fig.findobj(match=Text):
        text.set_fontsize(text.get_fontsize() * 1.38)
    for suffix in ['pdf', 'svg', 'png']:
        fig.savefig(FIG / f'{name}.{suffix}', dpi=600, facecolor='white')
    plt.close(fig)


def label(ax, letter):
    ax.text(-0.13, 1.075, letter, transform=ax.transAxes, fontsize=10, fontweight='bold', va='bottom')


def main():
    plt.rcParams.update({'font.family': 'sans-serif', 'font.sans-serif': ['Arial', 'DejaVu Sans'],
                         'font.size': 8.5, 'axes.labelsize': 8.5, 'axes.titlesize': 9,
                         'xtick.labelsize': 8, 'ytick.labelsize': 8, 'legend.fontsize': 8,
                         'axes.linewidth': 0.7, 'pdf.fonttype': 42, 'svg.fonttype': 'none'})
    cells = pd.read_csv(DATA / 'all240_context_cells.csv')
    effects = pd.read_csv(DATA / 'context_effects24.csv')
    factorial = pd.read_csv(DATA / 'factorial_summary24.csv')
    endpoints = pd.read_csv(DATA / 'v10_endpoint_strata.csv')
    assert len(effects) == 24 and len(factorial) == 24
    # Figure 1: three explicit layers; the deterministic source reference is separate from inputs.
    fig, ax = plt.subplots(figsize=(7.08, 4.8))
    ax.set(xlim=(0, 1), ylim=(0, 1))
    ax.set_axis_off()
    def box(x, y, w, h, title, body, fill='#F0F4F6'):
        ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle='round,pad=0.006,rounding_size=0.008',
                                    linewidth=0.8, edgecolor='#A8BCC6', facecolor=fill))
        ax.text(x+w/2, y+h*0.72, title, ha='center', va='center', fontsize=9, weight='bold', color=INK)
        ax.text(x+w/2, y+h*0.31, body, ha='center', va='center', fontsize=8, linespacing=1.4, color=INK)
    def arrow(x1, y1, x2, y2):
        ax.add_patch(FancyArrowPatch((x1,y1), (x2,y2), arrowstyle='-|>', mutation_scale=10,
                                    linewidth=0.8, color=SLATE))
    ax.text(0.015, 0.97, 'Controlled input perturbations', fontsize=10, weight='bold', va='top')
    for x, title, body in [(0.02, 'Evidence states', 'Laboratory values\nMeasurement timestamps'),
                            (0.352, 'Rule presentation', 'Implicit / explicit\nFixed source-rule reference'),
                            (0.684, 'Context visibility', 'Reduced / full\nClock retained for HbA1c')]:
        box(x, 0.745, 0.295, 0.15, title, body)
        arrow(x+0.1475, 0.738, x+0.1475, 0.674)
    ax.text(0.015, 0.65, 'Evaluated decision components', fontsize=10, weight='bold', va='top')
    box(0.06, 0.445, 0.39, 0.14, 'Typed Jev probes', 'Native scores / choices\nFrozen interface-specific policy', '#E4F1F2')
    box(0.55, 0.445, 0.39, 0.14, 'Generative chat models', 'Action label / confidence\nStrict text contract', '#E4F1F2')
    # Route outputs through a common evaluation junction without implying an agent loop.
    ax.plot([0.42,0.42], [0.438,0.355], color=SLATE, lw=0.8)
    ax.plot([0.745,0.745], [0.438,0.355], color=SLATE, lw=0.8)
    ax.plot([0.1675,0.8315], [0.355,0.355], color=SLATE, lw=0.8)
    for x in [0.1675, 0.5, 0.8315]:
        arrow(x, 0.355, x, 0.28)
    ax.text(0.015, 0.415, 'Layered evaluation', fontsize=10, weight='bold', va='top')
    box(0.02, 0.075, 0.295, 0.19, 'State ranking', 'Five-state mean scores\nAUROC for native scores')
    box(0.352, 0.075, 0.295, 0.19, 'Rule-action alignment', 'Selected action vs.\ndeterministic source rule')
    box(0.684, 0.075, 0.295, 0.19, 'Interface validity', 'I: invalid / all\nC: correct / all\nM: mismatch / valid')
    fig.subplots_adjust(left=0.015, right=0.985, bottom=0.01, top=0.99)
    save(fig, 'fig1_testing_chain')
    # Figure 2: descriptive state means and technical replicate SD; native policy actions remain distinct.
    fig, axes = plt.subplots(2, 3, figsize=(7.08, 4.6), sharex=True)
    values = [1.68,1.70,1.88,1.90,1.92]
    for j, arm in enumerate(ARMS):
        for context, color, marker, ls, face in [('reduced',SLATE,'o','--',SLATE), ('full',TEAL,'s','-', 'white')]:
            g = cells[(cells.family=='task5') & (cells['mode']=='implicit') & (cells.arm==arm) & (cells.context==context)].sort_values('x')
            assert len(g)==5 and g.n.eq(5).all()
            axes[0,j].errorbar(range(5), g.score_mean, yerr=g.score_sd, color=color, marker=marker,
                              markerfacecolor=face, markersize=4, linestyle=ls, linewidth=1.1,
                              capsize=2, elinewidth=0.6, label=context.capitalize()+' context')
            axes[1,j].plot(range(5), g.action_frequency, color=color, marker=marker,
                           markerfacecolor=face, markersize=4, linestyle=ls, lw=1.1)
        axes[0,j].set_title(SHORT[j]+'\nAUROC = 1\nin both contexts', pad=7)
        axes[1,j].plot(range(5), [1,1,1,1,0], ':', color='#888888', lw=1.4, label='Source-rule target', zorder=1)
        axes[1,j].set_xticks(range(5), [f'{x:.2f}' for x in values], rotation=45, ha='right', rotation_mode='anchor')
        axes[1,j].set_xlabel('Mg (mg/dL)')
        for ax in axes[:,j]:
            ax.set_ylim(-0.07,1.12)
            ax.set_yticks([0,.5,1])
            clean(ax)
        if j:
            for ax in axes[:,j]: ax.tick_params(labelleft=False)
    axes[0,0].set_ylabel('Mean target\nscore')
    axes[1,0].set_ylabel('Target action\nfrequency')
    label(axes[0,0], 'a')
    label(axes[1,0], 'b')
    handles = [Line2D([],[],color=SLATE,marker='o',ls='--',label='Reduced context'),
               Line2D([],[],color=TEAL,marker='s',mfc='white',label='Full context'),
               Line2D([],[],color='#888888',ls=':',label='Source-rule target (actions)')]
    fig.legend(handles=handles, loc='lower center', bbox_to_anchor=(.53,.005), ncol=3, frameon=False, fontsize=8)
    fig.subplots_adjust(left=.11,right=.98,bottom=.25,top=.79,wspace=.23,hspace=.43)
    save(fig, 'fig2_ranking_action')
    # Figure 3: all 24 strata, with complete instruction labels and a legend for each task panel.
    fig, axes = plt.subplots(1,2,figsize=(7.08,5.1), sharey=True)
    rowlabels = [f'{m} / {mode}' for m in SHORT for mode in ['Implicit','Explicit']]
    for col,family in enumerate(['task5','task9']):
        ax=axes[col]
        for mi,model in enumerate(MODELS):
            for mode_i,mode in enumerate(['implicit','explicit']):
                r=effects[(effects.instrument==model)&(effects.family==family)&(effects['mode']==mode)].iloc[0]
                y=mi*2+mode_i
                ax.plot([100*r.reduced_C,100*r.full_C],[y,y],color='#B9C8CF',lw=1.5,zorder=1)
                ax.scatter(100*r.reduced_C,y,s=27,c=SLATE,marker='o',zorder=3)
                ax.scatter(100*r.full_C,y,s=55,facecolors='none',edgecolors=TEAL,linewidths=1.1,marker='D',zorder=4)
        ax.set(xlim=(-5,105),xticks=[0,25,50,75,100],xlabel='Strict correctness (%)')
        ax.set_title(['Magnesium','Potassium + recheck'][col],pad=10)
        clean(ax)
        handles=[Line2D([],[],ls='',marker='o',color=SLATE,label='Reduced context'),
                 Line2D([],[],ls='',marker='D',mfc='none',mec=TEAL,label='Full context')]
        ax.legend(handles=handles,loc='upper center',bbox_to_anchor=(.5,-.17),frameon=False,ncol=1)
        label(ax,['a','b'][col])
    axes[0].set_yticks(range(12),rowlabels)
    axes[0].invert_yaxis()
    axes[1].tick_params(labelleft=False)
    fig.subplots_adjust(left=.29,right=.98,bottom=.24,top=.90,wspace=.24)
    save(fig,'fig3_context_strata')
    # Figure 4: deterministic categorical offsets separate all six markers at ceiling.
    fig,axes=plt.subplots(1,2,figsize=(7.08,3.7),sharey=True)
    for col,mode in enumerate(['implicit','explicit']):
        ax=axes[col]
        for ai,arm in enumerate(ARMS):
            g=factorial[(factorial['mode']==mode)&(factorial.arm==arm)].set_index('context')
            assert len(g)==4 and g.n.eq(25).all()
            for rv,color,ls in [(0,SLATE,'--'),(1,TEAL,'-')]:
                xpos=np.array([0,1])+(rv-.5)*.23+(ai-1)*.065
                rates=[100*g.loc[f'L{lv}R{rv}','correct_calls']/25 for lv in [0,1]]
                ax.plot(xpos,rates,marker=['o','s','^'][ai],mfc='white' if rv else color,
                        color=color,ls=ls,markersize=4.5,lw=.9)
        ax.set_xticks([0,1],['Neutral names\n(L0)','Severity names\n(L1)'])
        ax.set(xlim=(-.30,1.30),ylim=(-4,110),yticks=[0,25,50,75,100])
        ax.set_title(mode.capitalize()+' instruction',pad=12)
        clean(ax);label(ax,['a','b'][col])
    axes[0].set_ylabel('Strict correctness (%)')
    handles=[Line2D([],[],color=SLATE,ls='--',label='Ranges removed (R0)'),Line2D([],[],color=TEAL,label='Ranges retained (R1)')]
    fig.legend(handles=handles,loc='lower center',bbox_to_anchor=(.52,.085),ncol=2,frameon=False)
    fig.text(.53,.025,'Markers: circle Noul; square Choice; triangle Choice+DEFER',ha='center',fontsize=8)
    fig.subplots_adjust(left=.09,right=.98,bottom=.32,top=.87,wspace=.22)
    save(fig,'fig4_factorial')
    # Figure 5: exact counts and percentages, zero-based independent endpoint scales.
    fig,axes=plt.subplots(1,3,figsize=(7.08,3.9))
    overall=endpoints[endpoints.family=='ALL'].set_index('condition')
    assert overall.loc['control','n']==200 and overall.loc['constrained','n']==200
    for j,(metric,denom,title,top) in enumerate([('invalid','n','Contract invalidity',6),('correct','n','Strict correctness',112),('rule_mismatch','valid','Valid rule mismatch',14)]):
        ax=axes[j]
        for pos,cond in enumerate(['control','constrained']):
            r=overall.loc[cond]; rate=100*r[metric]/r[denom]
            ax.bar(pos,rate,width=.55,color=[SLATE,TEAL][pos])
            ax.text(pos,rate+top*.035,f'{rate:.1f}%\n{int(r[metric])}/{int(r[denom])}',ha='center',va='bottom',fontsize=8,linespacing=1.25)
        ax.set_xticks([0,1],['Baseline\ncondition','Contract\nreminder\nintervention'],rotation=0)
        ax.set_title(title,pad=12)
        ax.set_ylim(0,top)
        if j==1: ax.set_yticks([0,25,50,75,100])
        ax.set_ylabel('%')
        clean(ax);label(ax,['a','b','c'][j])
    fig.subplots_adjust(left=.08,right=.98,bottom=.30,top=.82,wspace=.65)
    save(fig,'fig5_contract_endpoints')
    manifest=[]
    for p in sorted(FIG.glob('*')):
        if p.suffix in ['.pdf','.svg','.png']:
            manifest.append({'file':p.name,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size})
    (WORK/'figure_manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
    print(json.dumps({'main_figures_redrawn':5,'data_rows_unchanged':True,'exports':['PDF','SVG','600dpi PNG']}))


if __name__=='__main__':
    main()
